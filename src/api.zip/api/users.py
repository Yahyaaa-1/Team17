from flask import jsonify, request
from flask.views import MethodView
from werkzeug.security import generate_password_hash, check_password_hash
from database import get_db_connection  # A shared database connection utility


class UserRegistrationAPI(MethodView):
    def post(self):
        try:
            data = request.get_json()
            if not data:
                return jsonify({'success': False, 'error': 'No data received'}), 400

            full_name = data.get('full_name')
            email = data.get('email')
            new_password = data.get('new_password')

            if not all([full_name, email, new_password]):
                return jsonify({'success': False, 'error': 'Missing required fields'}), 400

            connection = get_db_connection()
            cursor = connection.cursor(dictionary=True)

            cursor.execute("SELECT * FROM user_accounts WHERE email = %s", (email,))
            existing_user = cursor.fetchone()
            if existing_user:
                cursor.close()
                connection.close()
                return jsonify({'success': False, 'error': 'User already registered'}), 400

            hashed_password = generate_password_hash(new_password)

            cursor.execute("""
                INSERT INTO user_accounts (email, full_name, password, admin, active, dark_mode)
                VALUES (%s, %s, %s, %s, %s, %s)
            """, (email, full_name, hashed_password, 0, 0, 0))

            connection.commit()
            cursor.close()
            connection.close()

            return jsonify({'success': True, 'message': 'Registration successful'})
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 400


class UserLoginAPI(MethodView):
    def post(self):
        try:
            data = request.get_json()
            email = data.get('email')
            password = data.get('password')

            connection = get_db_connection()
            cursor = connection.cursor(dictionary=True)
            cursor.execute("SELECT * FROM user_accounts WHERE email = %s", (email,))
            user = cursor.fetchone()

            if not user or not check_password_hash(user['password'], password):
                cursor.close()
                connection.close()
                return jsonify({'success': False, 'error': 'Invalid credentials'}), 401

            cursor.close()
            connection.close()

            return jsonify({'success': True, 'message': 'Login successful', 'user': user['email']})
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 400
