from flask import jsonify, request
from flask.views import MethodView
from database import get_db_connection


class AdminRoutes(MethodView):
    @staticmethod
    def get_user_accounts():
        try:
            connection = get_db_connection()
            cursor = connection.cursor(dictionary=True)
            cursor.execute("SELECT * FROM user_accounts")
            users = cursor.fetchall()
            cursor.close()
            connection.close()
            return jsonify({'success': True, 'users': users})
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 500

    @staticmethod
    def toggle_user_admin():
        try:
            data = request.get_json()
            operator_id = data.get('operator_id')

            if not operator_id:
                return jsonify({'success': False, 'error': 'Missing Operator id'}), 400

            connection = get_db_connection()
            cursor = connection.cursor()

            cursor.execute("SELECT admin FROM user_accounts WHERE operator_id = %s", (operator_id,))
            user = cursor.fetchone()

            if user:
                new_status = 0 if user['admin'] == 1 else 1
                cursor.execute("UPDATE user_accounts SET admin = %s WHERE operator_id = %s", (new_status, operator_id))
                connection.commit()
                cursor.close()
                connection.close()
                return jsonify({'success': True, 'message': f"User admin status updated to {new_status}"})
            else:
                return jsonify({'success': False, 'error': 'User not found'}), 404
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 500
