from flask import jsonify, request
from flask.views import MethodView
from database import get_db_connection


class SensorRoutes(MethodView):
    @staticmethod
    def live_sensor_data(line):
        try:
            connection = get_db_connection()
            cursor = connection.cursor(dictionary=True)
            valid_lines = ["line4", "line5"]
            if line not in valid_lines:
                return jsonify({'error': 'Invalid line selected'}), 400

            query = f"SELECT * FROM {line} ORDER BY timestamp DESC LIMIT 1"
            cursor.execute(query)
            data = cursor.fetchone()

            if not data:
                return jsonify({'error': 'No live data available'}), 404

            data["timestamp"] = data["timestamp"].strftime("%Y-%m-%d %H:%M:%S")
            return jsonify({'success': True, 'data': data}), 200

        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            if connection:
                connection.close()

    @staticmethod
    def historical_data_sensor(line, sensor):
        try:
            connection = get_db_connection()
            cursor = connection.cursor(dictionary=True)
            query = f"SELECT timestamp, {sensor} FROM {line} ORDER BY timestamp DESC LIMIT 1"
            cursor.execute(query)
            data = cursor.fetchone()

            if not data:
                return jsonify({'error': 'No data available for this sensor'}), 404

            data["timestamp"] = data["timestamp"].strftime("%Y-%m-%d %H:%M:%S")
            return jsonify({'success': True, 'data': data}), 200

        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            if connection:
                connection.close()

    @staticmethod
    def forecasted_data(line):
        try:
            connection = get_db_connection()
            cursor = connection.cursor(dictionary=True)
            valid_lines = ["line4", "line5"]
            if line not in valid_lines:
                return jsonify({'error': 'Invalid line selected'}), 400

            query = f"SELECT * FROM forecasted{line} ORDER BY forecast_time ASC"
            cursor.execute(query)
            data = cursor.fetchall()

            if not data:
                return jsonify({'error': 'No forecasted data available'}), 404

            for record in data:
                record["forecast_time"] = record["forecast_time"].strftime("%Y-%m-%d %H:%M:%S")

            return jsonify({'success': True, 'data': data}), 200

        except Exception as e:
            return jsonify({'error': str(e)}), 500
        finally:
            if connection:
                connection.close()
