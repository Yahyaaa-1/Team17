from flask import Flask
from flask_cors import CORS
from config import Config
from users import UserRegistrationAPI, UserLoginAPI
from admin import AdminRoutes
from sensor import SensorRoutes
from logging import LoggingRoutes

app = Flask(__name__)
app.config.from_object(Config)  # Load configuration from Config class
CORS(app, resources={r"/api/*": {"origins": "*"}})

# Register Routes
app.add_url_rule('/api/register', view_func=UserRegistrationAPI.as_view('register'))
app.add_url_rule('/api/login', view_func=UserLoginAPI.as_view('login'))
app.add_url_rule('/api/admin/user-accounts', view_func=AdminRoutes.get_user_accounts)
app.add_url_rule('/api/admin/toggle-user-admin', view_func=AdminRoutes.toggle_user_admin)
app.add_url_rule('/api/live-data/<line>', view_func=SensorRoutes.live_sensor_data)
app.add_url_rule('/api/log', view_func=LoggingRoutes.trigger_log)

if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)
