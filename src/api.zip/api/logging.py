from flask.views import MethodView  # Keep MethodView import globally
from database import get_db_connection
import logging

class LoggingRoutes(MethodView):
    @staticmethod
    def trigger_log():
        from flask import jsonify, request  # Only move these imports inside the function

        try:
            data = request.get_json()
            message = data.get('message')
            log_level = data.get('level', 'admin')
            type = data.get('type', 'INFO')

            connection = get_db_connection()
            cursor = connection.cursor()
            cursor.execute("""
                INSERT INTO logs (level, type, message) 
                VALUES (%s, %s, %s)
            """, (log_level, type, message))
            connection.commit()
            cursor.close()
            connection.close()

            return jsonify({'success': True, 'message': 'Log event triggered'})
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 500
